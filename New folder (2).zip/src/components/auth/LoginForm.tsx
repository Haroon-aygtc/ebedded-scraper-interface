import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { MessageSquare, Lock, User, ShieldCheck, ArrowRight } from "lucide-react";

const LoginForm = () => {
  const [email, setEmail] = useState("admin@example.com");
  const [password, setPassword] = useState("******");
  const { login, isLoading, error, clearError } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await login(email, password);

    if (success) {
      // Redirect based on user role
      const userStr = localStorage.getItem("user");
      if (userStr) {
        try {
          const user = JSON.parse(userStr);
          if (user.role === "admin") {
            navigate("/admin/dashboard");
          } else {
            navigate("/dashboard"); // Regular user dashboard
          }
        } catch (error) {
          navigate("/admin/dashboard"); // Fallback
        }
      } else {
        navigate("/admin/dashboard"); // Fallback
      }
    }
  };

  // Function to handle mock admin login
  const handleAdminLogin = async () => {
    const success = await login("admin@example.com", "admin123");
    if (success) {
      navigate("/admin/dashboard");
    }
  };

  // Function to handle mock user login
  const handleUserLogin = async () => {
    const success = await login("user@example.com", "user123");
    if (success) {
      navigate("/dashboard"); // Regular user dashboard
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <Card className="w-full max-w-md shadow-xl overflow-hidden border border-primary/20">
        <CardHeader className="space-y-1 text-center">
          <div className="flex items-center justify-center mb-2">
            <MessageSquare className="h-6 w-6 text-primary" />
          </div>
          <CardTitle className="text-xl font-bold">
            Welcome Back
          </CardTitle>
          <CardDescription className="text-foreground/70 dark:text-foreground/60">
            Enter your credentials to access the dashboard
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-foreground/90 dark:text-foreground/80">Email</Label>
              <div className="relative">
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@example.com"
                  value={email}
                  onChange={(e) => {
                    clearError();
                    setEmail(e.target.value);
                  }}
                  required
                  className="pl-8 border border-input dark:border-input/50 focus:border-primary/70"
                />
                <div className="absolute left-2.5 top-1/2 -translate-y-1/2 text-primary/70">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect width="20" height="16" x="2" y="4" rx="2" />
                    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                  </svg>
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground/90 dark:text-foreground/80">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => {
                    clearError();
                    setPassword(e.target.value);
                  }}
                  required
                  className="pl-8 border border-input dark:border-input/50 focus:border-primary/70"
                />
                <div className="absolute left-2.5 top-1/2 -translate-y-1/2 text-primary/70">
                  <Lock size={16} />
                </div>
              </div>
            </div>
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              disabled={isLoading}
            >
              {isLoading ? "Logging in..." : (
                <span className="flex items-center justify-center">
                  Login <ArrowRight className="ml-2 h-4 w-4" />
                </span>
              )}
            </Button>
          </form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <Separator className="w-full border-primary/20" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-foreground/70 dark:text-foreground/60">
                  QUICK ACCESS
                </span>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={handleAdminLogin}
                className="flex items-center justify-center gap-2 hover:bg-primary/10 hover:text-primary border border-input dark:border-input/50"
              >
                <ShieldCheck className="h-4 w-4" />
                Admin Login
              </Button>
              <Button
                variant="outline"
                onClick={handleUserLogin}
                className="flex items-center justify-center gap-2 hover:bg-primary/10 hover:text-primary border border-input dark:border-input/50"
              >
                <User className="h-4 w-4" />
                User Login
              </Button>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center text-xs text-foreground/60 dark:text-foreground/50 pt-0">
          Admin: admin@example.com / admin123
        </CardFooter>
      </Card>
    </div>
  );
};

export default LoginForm;
