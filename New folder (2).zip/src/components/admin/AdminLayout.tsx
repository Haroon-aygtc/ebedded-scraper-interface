import React, { useState, useEffect } from "react";
import Sidebar from "./Sidebar";
import DashboardHeader from "./DashboardHeader";
import ThemeCustomizer from "@/components/ThemeCustomizer";
import { useTheme } from "@/components/ThemeProvider";

interface AdminLayoutProps {
  children: React.ReactNode;
}

const AdminLayout: React.FC<AdminLayoutProps> = ({ children }) => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mounted, setMounted] = useState(false);

  // Ensure hydration completes before rendering to avoid mismatch
  useEffect(() => {
    setMounted(true);
    console.log("Mounted");
  }, []);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  console.log("AdminLayout");

  // Don't render until client-side to avoid hydration mismatch with theme
  if (!mounted) return null;

  return (
    <div className="flex h-screen bg-background transition-all duration-300">
      {/* Sidebar - hidden on small screens, visible on medium and up */}
      <div
        className={`${sidebarCollapsed ? 'hidden sm:block sm:w-20' : 'hidden sm:block'} transition-all duration-300 animate-fadeIn`}
        style={{ width: sidebarCollapsed ? '80px' : 'var(--sidebar-width, 260px)' }}
      >
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggleCollapse={toggleSidebar}
          userName="Admin User"
          userEmail="admin@example.com"
        />
      </div>

      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden bg-background">
        <DashboardHeader
          title="Admin Dashboard"
          username="Admin User"
          userAvatar="https://api.dicebear.com/7.x/avataaars/svg?seed=admin"
          notificationCount={3}
          onToggleSidebar={toggleSidebar}
          isSidebarCollapsed={sidebarCollapsed}
        />
        <main className="flex-1 overflow-y-auto transition-all duration-300 animate-fadeIn bg-background px-0">
          <div className="mx-auto w-full" style={{ maxWidth: 'var(--content-max-width, 1400px)' }}>
            {children}
          </div>
        </main>
      </div>

      {/* Theme Customizer */}
      <ThemeCustomizer />
    </div>
  );
};

export default AdminLayout;
