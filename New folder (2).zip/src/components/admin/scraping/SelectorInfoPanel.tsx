import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Info, Code, Save, Copy, ExternalLink, BookOpen, FileText, CheckCircle } from "lucide-react";

interface SelectorInfoPanelProps {
  className?: string;
}

const SelectorInfoPanel: React.FC<SelectorInfoPanelProps> = ({ className }) => {
  return (
    <Card className={`${className} border-primary/20 dark:border-primary/30 shadow-md`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Info className="h-5 w-5 text-primary" />
            Selector Guide
          </CardTitle>
          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
            Tips & Tricks
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-sm font-medium mb-2 flex items-center gap-2">
            <Code className="h-4 w-4 text-blue-500" />
            CSS Selector Basics
          </h3>
          <ul className="text-sm space-y-2 text-gray-600 dark:text-gray-300">
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span><code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">#id</code> - Select elements with a specific ID</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span><code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">.class</code> - Select elements with a specific class</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span><code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">element</code> - Select elements by tag name</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span><code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">[attr=value]</code> - Select elements with a specific attribute value</span>
            </li>
          </ul>
        </div>

        <Separator />

        <div>
          <h3 className="text-sm font-medium mb-2 flex items-center gap-2">
            <FileText className="h-4 w-4 text-orange-500" />
            Advanced Techniques
          </h3>
          <ul className="text-sm space-y-2 text-gray-600 dark:text-gray-300">
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span>Use <code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">:nth-child(n)</code> to select specific children</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span>Combine selectors with <code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">&gt;</code> for direct children</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span>Use <code className="bg-gray-100 dark:bg-gray-800 px-1 rounded">:contains("text")</code> for text matching</span>
            </li>
          </ul>
        </div>

        <Separator />

        <div>
          <h3 className="text-sm font-medium mb-2 flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-purple-500" />
            Best Practices
          </h3>
          <ul className="text-sm space-y-2 text-gray-600 dark:text-gray-300">
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span>Use specific selectors to avoid matching unwanted elements</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span>Test selectors on different pages to ensure consistency</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
              <span>Group related selectors for better organization</span>
            </li>
          </ul>
        </div>

        <div className="pt-2">
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" className="w-full">
              <Save className="h-4 w-4 mr-2" />
              Save Template
            </Button>
            <Button variant="outline" size="sm" className="w-full">
              <ExternalLink className="h-4 w-4 mr-2" />
              Documentation
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SelectorInfoPanel;
