import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/AuthContext";
import {
  LayoutDashboard,
  Settings,
  MessageSquare,
  Code,
  BarChart3,
  FileText,
  Users,
  ChevronDown,
  ChevronRight,
  LogOut,
  Globe,
  MessageCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface SidebarProps {
  collapsed?: boolean;
  onToggleCollapse?: () => void;
  userName?: string;
  userEmail?: string;
  userAvatar?: string;
}

const Sidebar = ({
  collapsed = false,
  onToggleCollapse = () => {},
  userName = "Admin User",
  userEmail = "admin@example.com",
  userAvatar = "https://api.dicebear.com/7.x/avataaars/svg?seed=admin",
}: SidebarProps) => {
  const location = useLocation();
  const [activeItem, setActiveItem] = useState("");
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({
    contextRules: false,
    templates: false,
    scraping: false,
  });

  // Update active item based on current route
  useEffect(() => {
    const path = location.pathname;

    // Set active item based on current path
    if (path.includes('/admin/dashboard')) {
      setActiveItem('dashboard');
    } else if (path.includes('/admin/widget-config')) {
      setActiveItem('widget');
    } else if (path.includes('/admin/context-rules')) {
      setActiveItem('contextRules');
      setExpandedMenus(prev => ({ ...prev, contextRules: true }));

      // Handle submenu items
      if (path.includes('/create')) {
        setActiveItem('contextRules-create');
      } else if (path.includes('/manage')) {
        setActiveItem('contextRules-manage');
      } else if (path.includes('/test')) {
        setActiveItem('contextRules-test');
      }
    } else if (path.includes('/admin/templates')) {
      setActiveItem('templates');
      setExpandedMenus(prev => ({ ...prev, templates: true }));

      // Handle submenu items
      if (path.includes('/create')) {
        setActiveItem('templates-create');
      } else if (path.includes('/manage')) {
        setActiveItem('templates-manage');
      }
    } else if (path.includes('/admin/scraping')) {
      setActiveItem('scraping');
      setExpandedMenus(prev => ({ ...prev, scraping: true }));

      // Handle submenu items
      if (path.includes('/configurator')) {
        setActiveItem('scraping-configurator');
      } else if (path.includes('/advanced-selector')) {
        setActiveItem('scraping-advanced-selector');
      } else if (path.includes('/selectors')) {
        setActiveItem('scraping-selectors');
      } else if (path.includes('/history')) {
        setActiveItem('scraping-history');
      } else if (path.includes('/problems')) {
        setActiveItem('scraping-problems');
      } else if (path.includes('/visualization')) {
        setActiveItem('scraping-visualization');
      }
    } else if (path.includes('/admin/embed-code')) {
      setActiveItem('embedCode');
    } else if (path.includes('/admin/analytics')) {
      setActiveItem('analytics');
    } else if (path.includes('/admin/response-formatter')) {
      setActiveItem('responseFormatter');
    }
  }, [location.pathname]);

  const toggleMenu = (menu: string) => {
    setExpandedMenus((prev) => ({
      ...prev,
      [menu]: !prev[menu],
    }));
  };

  const menuItems = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: <LayoutDashboard size={20} />,
      path: "/admin/dashboard",
    },
    {
      id: "widget",
      label: "Widget Config",
      icon: <Settings size={20} />,
      path: "/admin/widget-config",
    },
    {
      id: "contextRules",
      label: "Context Rules",
      icon: <MessageSquare size={20} />,
      path: "/admin/context-rules",
      submenu: [
        {
          id: "create",
          label: "Create Rule",
          path: "/admin/context-rules/create",
        },
        {
          id: "manage",
          label: "Manage Rules",
          path: "/admin/context-rules/manage",
        },
        { id: "test", label: "Test Rules", path: "/admin/context-rules/test" },
      ],
    },
    {
      id: "templates",
      label: "Prompt Templates",
      icon: <FileText size={20} />,
      path: "/admin/templates",
      submenu: [
        {
          id: "create",
          label: "Create Template",
          path: "/admin/templates/create",
        },
        {
          id: "manage",
          label: "Manage Templates",
          path: "/admin/templates/manage",
        },
      ],
    },
    {
      id: "scraping",
      label: "Web Scraping",
      icon: <Globe size={20} />,
      path: "/admin/scraping",
      submenu: [
        {
          id: "configurator",
          label: "Scraping Tool",
          path: "/admin/scraping/configurator",
        },
        {
          id: "advanced-selector",
          label: "Advanced Selector",
          path: "/admin/scraping/advanced-selector",
        },
        {
          id: "selectors",
          label: "Saved Selectors",
          path: "/admin/scraping/selectors",
        },
        {
          id: "history",
          label: "Scraping History",
          path: "/admin/scraping/history",
        },
        {
          id: "problems",
          label: "Potential Problems",
          path: "/admin/scraping/problems",
        },
        {
          id: "visualization",
          label: "Visualization",
          path: "/admin/scraping/visualization",
        },
      ],
    },
    {
      id: "embedCode",
      label: "Embed Code",
      icon: <Code size={20} />,
      path: "/admin/embed-code",
    },
    {
      id: "analytics",
      label: "Analytics",
      icon: <BarChart3 size={20} />,
      path: "/admin/analytics",
    },
    {
      id: "responseFormatter",
      label: "Response Formatter",
      icon: <MessageCircle size={20} />,
      path: "/admin/response-formatter",
    },
    {
      id: "users",
      label: "User Management",
      icon: <Users size={20} />,
      path: "/admin/users",
    },
  ];

  return (
    <div
      className="flex flex-col h-full bg-primary text-primary-foreground transition-all duration-300 glass-effect"
      style={{ width: collapsed ? '80px' : 'var(--sidebar-width, 260px)' }}
    >
      {/* Logo and collapse button */}
      <div
        className="flex items-center justify-between p-4 border-b border-primary-foreground/20"
        style={{ height: 'var(--header-height, 72px)', display: 'flex', alignItems: 'center' }}
      >
        {!collapsed && (
          <div className="flex items-center gap-2">
            <MessageSquare className="text-primary-foreground" size={24} />
            <span className="font-bold text-lg">ChatAdmin</span>
          </div>
        )}
        {collapsed && (
          <MessageSquare className="text-primary-foreground mx-auto" size={24} />
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          className={cn(
            "text-primary-foreground/70 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-colors duration-200",
            collapsed && "mx-auto",
          )}
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronDown size={20} />}
        </Button>
      </div>

      {/* User profile */}
      <div
        className={cn(
          "flex items-center p-4 border-b border-primary-foreground/20",
          collapsed ? "flex-col" : "gap-3",
        )}
      >
        <Avatar className="h-10 w-10">
          <AvatarImage src={userAvatar} alt={userName} />
          <AvatarFallback className="bg-accent">
            {userName.substring(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        {!collapsed && (
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{userName}</p>
            <p className="text-xs text-primary-foreground/70 truncate">{userEmail}</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4 scrollbar-thin scrollbar-thumb-primary-foreground/30 scrollbar-track-primary-foreground/10">
        <ul className="space-y-1 px-2">
          {menuItems.map((item) => (
            <li key={item.id}>
              {item.submenu ? (
                <div>
                  <Button
                    variant="ghost"
                    className={cn(
                      "w-full justify-start text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-all duration-200 hover-scale",
                      activeItem === item.id && "bg-primary-foreground/20 text-primary-foreground",
                      collapsed && "justify-center px-2",
                    )}
                    onClick={() => !collapsed && toggleMenu(item.id)}
                  >
                    <TooltipProvider delayDuration={300}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="flex items-center">
                            {item.icon}
                            {!collapsed && (
                              <>
                                <span className="ml-3 flex-1 text-left">
                                  {item.label}
                                </span>
                                {expandedMenus[item.id] ? (
                                  <ChevronDown size={16} />
                                ) : (
                                  <ChevronRight size={16} />
                                )}
                              </>
                            )}
                          </span>
                        </TooltipTrigger>
                        {collapsed && (
                          <TooltipContent side="right">
                            {item.label}
                          </TooltipContent>
                        )}
                      </Tooltip>
                    </TooltipProvider>
                  </Button>

                  {!collapsed && expandedMenus[item.id] && (
                    <ul className="mt-1 pl-10 space-y-1">
                      {item.submenu.map((subItem) => (
                        <li key={`${item.id}-${subItem.id}`}>
                          <Link
                            to={subItem.path}
                            className={cn(
                              "block py-2 px-3 text-sm rounded-md text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-all duration-200 hover-scale",
                              activeItem === `${item.id}-${subItem.id}` &&
                                "bg-primary-foreground/20 text-primary-foreground",
                            )}
                          >
                            {subItem.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : (
                <Link to={item.path}>
                  <Button
                    variant="ghost"
                    className={cn(
                      "w-full justify-start text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-all duration-200 hover-scale",
                      activeItem === item.id && "bg-primary-foreground/20 text-primary-foreground",
                      collapsed && "justify-center px-2",
                    )}

                  >
                    <TooltipProvider delayDuration={300}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="flex items-center">
                            {item.icon}
                            {!collapsed && (
                              <span className="ml-3">{item.label}</span>
                            )}
                          </span>
                        </TooltipTrigger>
                        {collapsed && (
                          <TooltipContent side="right">
                            {item.label}
                          </TooltipContent>
                        )}
                      </Tooltip>
                    </TooltipProvider>
                  </Button>
                </Link>
              )}
            </li>
          ))}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-primary-foreground/20">
        <Button
          variant="ghost"
          className={cn(
            "w-full justify-start text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10 transition-all duration-200 hover-scale",
            collapsed && "justify-center px-2",
          )}
          onClick={() => {
            const { logout } = useAuth();
            logout();
            window.location.href = "/login";
          }}
        >
          <TooltipProvider delayDuration={300}>
            <Tooltip>
              <TooltipTrigger asChild>
                <span className="flex items-center">
                  <LogOut size={20} />
                  {!collapsed && <span className="ml-3">Logout</span>}
                </span>
              </TooltipTrigger>
              {collapsed && (
                <TooltipContent side="right">Logout</TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </Button>
      </div>
    </div>
  );
};

export default Sidebar;
