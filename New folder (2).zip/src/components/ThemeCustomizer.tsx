import React, { useState, useEffect } from "react";
import { useTheme } from "@/components/ThemeProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
// Removed unused tooltip imports
import {
  Settings,
  Palette,
  Type,
  Layout,
  Check,
  X,
  RefreshCw,
  Sparkles,
} from "lucide-react";
import { HslColorPicker } from "react-colorful";
import { motion } from "framer-motion";

// Add custom styles for the ThemeCustomizer and react-colorful
const customStyles = `
  .react-colorful {
    width: 100% !important;
    height: 180px !important;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    position: relative;
  }

  .react-colorful__saturation {
    position: relative;
    border-radius: 8px 8px 0 0;
    border-bottom: none;
    flex-grow: 1;
    border-bottom: 12px solid #000;
    box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.05);
  }

  .react-colorful__hue {
    position: relative;
    height: 20px;
    border-radius: 0 0 8px 8px;
  }

  .react-colorful__interactive {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    border-radius: inherit;
    outline: none;
    touch-action: none;
  }

  .react-colorful__pointer {
    position: absolute;
    z-index: 1;
    box-sizing: border-box;
    width: 28px;
    height: 28px;
    transform: translate(-50%, -50%);
    background-color: #fff;
    border: 2px solid #fff;
    border-radius: 50%;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  }

  .react-colorful__saturation-pointer {
    z-index: 3;
  }

  .react-colorful__hue-pointer {
    z-index: 2;
  }

  /* Additional styles for the color picker */
  .react-colorful__saturation-area {
    position: relative;
    width: 100%;
    height: 160px;
    border-radius: 8px 8px 0 0;
    background: linear-gradient(to top, #000, rgba(0, 0, 0, 0));
  }

  .react-colorful__saturation-area .react-colorful__interactive {
    background: linear-gradient(to right, #fff, rgba(255, 255, 255, 0));
  }

  .react-colorful__hue-area {
    position: relative;
    width: 100%;
    height: 20px;
    border-radius: 0 0 8px 8px;
    background: linear-gradient(
      to right,
      #f00 0%,
      #ff0 17%,
      #0f0 33%,
      #0ff 50%,
      #00f 67%,
      #f0f 83%,
      #f00 100%
    );
  }
`;

interface ThemeSettings {
  fontSize: number;
  sidebarWidth: number;
  headerHeight: number;
  tabHeight: number;
  contentMaxWidth: number;
  primaryColor: string;
  primaryColorOpacity: number;
  secondaryColor: string;
  secondaryColorOpacity: number;
  accentColor: string;
  accentColorOpacity: number;
  backgroundColor: string;
  backgroundColorOpacity: number;
  borderRadius: number;
  animationSpeed: number;
  enableAnimations: boolean;
}

const defaultThemeSettings: ThemeSettings = {
  fontSize: 16,
  sidebarWidth: 260,
  headerHeight: 72,
  tabHeight: 56,
  contentMaxWidth: 1400,
  primaryColor: "hsl(221.2 83.2% 53.3%)",
  primaryColorOpacity: 100,
  secondaryColor: "hsl(215 20.2% 65.1%)",
  secondaryColorOpacity: 100,
  accentColor: "hsl(262.1 83.3% 57.8%)",
  accentColorOpacity: 100,
  backgroundColor: "hsl(220 14.3% 95.9%)",
  backgroundColorOpacity: 100,
  borderRadius: 8,
  animationSpeed: 300,
  enableAnimations: true,
};

const hslToString = (h: number, s: number, l: number) => `hsl(${h} ${s}% ${l}%)`;
const parseHsl = (hslString: string) => {
  const matches = hslString.match(/hsl\((\d+\.?\d*)\s+(\d+\.?\d*)%\s+(\d+\.?\d*)%\)/);
  if (matches) {
    return {
      h: parseFloat(matches[1]),
      s: parseFloat(matches[2]),
      l: parseFloat(matches[3])
    };
  }
  return { h: 0, s: 0, l: 0 };
};

const ThemeCustomizer: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const [settings, setSettings] = useState<ThemeSettings>(() => {
    // Try to load saved theme from localStorage
    const savedTheme = localStorage.getItem('ui-theme-settings');
    if (savedTheme) {
      try {
        return JSON.parse(savedTheme);
      } catch (e) {
        console.error('Failed to parse saved theme', e);
      }
    }
    return defaultThemeSettings;
  });
  const [isOpen, setIsOpen] = useState(false);
  const [themeName, setThemeName] = useState('My Custom Theme');
  const [savedThemes, setSavedThemes] = useState<{name: string, settings: ThemeSettings}[]>(() => {
    const saved = localStorage.getItem('ui-saved-themes');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse saved themes', e);
      }
    }
    return [];
  });

  // Apply settings to CSS variables
  useEffect(() => {
    const root = document.documentElement;

    // Base settings
    root.style.setProperty("--font-size-base", `${settings.fontSize}px`);
    root.style.setProperty("--sidebar-width", `${settings.sidebarWidth}px`);
    root.style.setProperty("--header-height", `${settings.headerHeight}px`);
    root.style.setProperty("--tab-height", `${settings.tabHeight}px`);
    root.style.setProperty("--content-max-width", `${settings.contentMaxWidth}px`);

    // Apply color settings with opacity
    const applyColorWithOpacity = (color: string, opacity: number, variable: string) => {
      // Parse the HSL color
      const hslMatch = color.match(/hsl\((\d+\.?\d*)\s+(\d+\.?\d*)%\s+(\d+\.?\d*)%\)/);
      if (hslMatch) {
        const [_, h, s, l] = hslMatch;
        root.style.setProperty(`--${variable}`, `${h} ${s}% ${l}%`);
        root.style.setProperty(`--${variable}-opacity`, `${opacity / 100}`);
      }
    };

    applyColorWithOpacity(settings.primaryColor, settings.primaryColorOpacity, "primary");
    applyColorWithOpacity(settings.secondaryColor, settings.secondaryColorOpacity, "secondary");
    applyColorWithOpacity(settings.accentColor, settings.accentColorOpacity, "accent");
    applyColorWithOpacity(settings.backgroundColor, settings.backgroundColorOpacity, "background");

    // Border radius and animation settings
    root.style.setProperty("--radius", `${settings.borderRadius}px`);
    root.style.setProperty("--animation-duration", `${settings.animationSpeed}ms`);

    // Animation toggle
    if (settings.enableAnimations) {
      root.classList.add("enable-animations");
    } else {
      root.classList.remove("enable-animations");
    }

    // Save settings to localStorage
    localStorage.setItem('ui-theme-settings', JSON.stringify(settings));
  }, [settings]);

  const updateSetting = <K extends keyof ThemeSettings>(
    key: K,
    value: ThemeSettings[K]
  ) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
  };

  const resetSettings = () => {
    setSettings(defaultThemeSettings);
    localStorage.removeItem('ui-theme-settings');
  };

  const saveTheme = () => {
    // Save current settings to localStorage
    localStorage.setItem('ui-theme-settings', JSON.stringify(settings));

    // Add to saved themes if it has a name
    if (themeName.trim()) {
      const newThemes = [...savedThemes.filter(t => t.name !== themeName), { name: themeName, settings }];
      setSavedThemes(newThemes);
      localStorage.setItem('ui-saved-themes', JSON.stringify(newThemes));
    }
  };

  const loadTheme = (themeSettings: ThemeSettings) => {
    setSettings(themeSettings);
    localStorage.setItem('ui-theme-settings', JSON.stringify(themeSettings));
  };

  return (
    <div className="fixed top-20 right-6 z-[9999] flex flex-col items-end gap-2 float-right">
      <style>{customStyles}</style>
      <div className="glass-effect px-3 py-1 rounded-full text-sm font-medium shadow-lg whitespace-nowrap mb-2 float-right">
        Customize UI
      </div>
      <div>
        <Popover open={isOpen} onOpenChange={setIsOpen}>
          <PopoverTrigger asChild>
            <Button
              size="icon"
              className="h-14 w-14 rounded-full shadow-xl bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 hover:scale-105 border-4 border-background dark:border-gray-800 pulse-on-hover attention-animation glass-effect"
              onClick={() => setIsOpen(true)}
            >
              <Settings className="h-7 w-7 animate-spin-slow" />
            </Button>
          </PopoverTrigger>
          <PopoverContent
            className="w-80 p-0 border-2 border-primary/20 shadow-xl glass-effect max-h-[80vh] overflow-y-auto"
            side="left"
            sideOffset={20}
            align="start"
          >
            <div className="bg-primary/5 p-3 flex justify-between items-center border-b glass-effect">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                <h3 className="font-semibold">UI Customizer</h3>
              </div>
              <div className="flex gap-1">
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7 rounded-full hover:bg-primary/10"
                  onClick={resetSettings}
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7 rounded-full hover:bg-primary/10"
                  onClick={() => setIsOpen(false)}
                >
                  <X className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>

            <Tabs defaultValue="layout" className="w-full">
              <TabsList className="w-full grid grid-cols-4 p-1 bg-transparent">
                <TabsTrigger value="layout" className="flex items-center gap-1 text-xs">
                  <Layout className="h-3.5 w-3.5" />
                  Layout
                </TabsTrigger>
                <TabsTrigger value="appearance" className="flex items-center gap-1 text-xs">
                  <Palette className="h-3.5 w-3.5" />
                  Appearance
                </TabsTrigger>
                <TabsTrigger value="typography" className="flex items-center gap-1 text-xs">
                  <Type className="h-3.5 w-3.5" />
                  Typography
                </TabsTrigger>
                <TabsTrigger value="themes" className="flex items-center gap-1 text-xs">
                  <Sparkles className="h-3.5 w-3.5" />
                  Themes
                </TabsTrigger>
              </TabsList>

              <div className="p-4">
                <TabsContent value="layout" className="space-y-4 mt-0">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label className="text-xs font-medium">Sidebar Width</Label>
                      <span className="text-xs font-semibold bg-primary/10 px-2 py-0.5 rounded-md text-primary">{settings.sidebarWidth}px</span>
                    </div>
                    <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                      <Slider
                        value={[settings.sidebarWidth]}
                        min={200}
                        max={320}
                        step={10}
                        onValueChange={(value) => updateSetting("sidebarWidth", value[0])}
                        className="py-1"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label className="text-xs font-medium">Header Height</Label>
                      <span className="text-xs font-semibold bg-primary/10 px-2 py-0.5 rounded-md text-primary">{settings.headerHeight}px</span>
                    </div>
                    <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                      <Slider
                        value={[settings.headerHeight]}
                        min={60}
                        max={100}
                        step={4}
                        onValueChange={(value) => updateSetting("headerHeight", value[0])}
                        className="py-1"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label className="text-xs font-medium">Tab Height</Label>
                      <span className="text-xs font-semibold bg-primary/10 px-2 py-0.5 rounded-md text-primary">{settings.tabHeight}px</span>
                    </div>
                    <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                      <Slider
                        value={[settings.tabHeight]}
                        min={40}
                        max={80}
                        step={4}
                        onValueChange={(value) => updateSetting("tabHeight", value[0])}
                        className="py-1"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label className="text-xs font-medium">Content Max Width</Label>
                      <span className="text-xs font-semibold bg-primary/10 px-2 py-0.5 rounded-md text-primary">{settings.contentMaxWidth}px</span>
                    </div>
                    <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                      <Slider
                        value={[settings.contentMaxWidth]}
                        min={1000}
                        max={1800}
                        step={50}
                        onValueChange={(value) => updateSetting("contentMaxWidth", value[0])}
                        className="py-1"
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="appearance" className="space-y-4 mt-0">
                  <div className="space-y-2">
                    <Label className="text-xs">Theme</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <Button
                        variant={theme === "light" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setTheme("light")}
                        className="w-full justify-start text-xs"
                      >
                        <span className="h-3 w-3 rounded-full bg-white border mr-2"></span>
                        Light
                      </Button>
                      <Button
                        variant={theme === "dark" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setTheme("dark")}
                        className="w-full justify-start text-xs"
                      >
                        <span className="h-3 w-3 rounded-full bg-gray-900 border mr-2"></span>
                        Dark
                      </Button>
                      <Button
                        variant={theme === "system" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setTheme("system")}
                        className="w-full justify-start text-xs"
                      >
                        <span className="h-3 w-3 rounded-full bg-gradient-to-r from-white to-gray-900 border mr-2"></span>
                        System
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                        {/* Color Pickers */}
                        <div className="space-y-4">
                          {/* Primary Color */}
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <Label className="text-xs">Primary Color</Label>
                              <div className="flex items-center gap-2">
                                <div
                                  className="h-4 w-4 rounded-full border"
                                  style={{ backgroundColor: settings.primaryColor }}
                                />
                                <span className="text-xs text-muted-foreground">{settings.primaryColorOpacity}%</span>
                              </div>
                            </div>
                            <Popover>
                              <PopoverTrigger asChild>
                                <Button
                                  variant="outline"
                                  className="w-full h-10 p-0 relative overflow-hidden border-2 border-primary/30 dark:border-primary/50"
                                >
                                  <div
                                    className="absolute inset-0"
                                    style={{ backgroundColor: settings.primaryColor }}
                                  />
                                  <div className="absolute inset-0 grid place-items-center bg-black/30">
                                    <Palette className="h-5 w-5 text-white drop-shadow-md" />
                                  </div>
                                </Button>
                              </PopoverTrigger>
                              <PopoverContent className="w-auto p-4 border-2 border-primary/30 dark:border-primary/50 shadow-xl" align="start">
                                <motion.div
                                  initial={{ opacity: 0, scale: 0.95 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  exit={{ opacity: 0, scale: 0.95 }}
                                  transition={{ duration: 0.2 }}
                                  className="w-[240px]"
                                >
                                  <div className="mb-2 flex justify-between items-center">
                                    <span className="text-xs font-medium">Color Picker</span>
                                    <div
                                      className="w-6 h-6 rounded-full border-2 border-white shadow-sm"
                                      style={{ backgroundColor: settings.primaryColor }}
                                    />
                                  </div>
                                  <HslColorPicker
                                    color={parseHsl(settings.primaryColor)}
                                    onChange={(color) => {
                                      updateSetting("primaryColor", hslToString(color.h, color.s, color.l));
                                    }}
                                  />
                                </motion.div>
                              </PopoverContent>
                            </Popover>
                            <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                              <Slider
                                value={[settings.primaryColorOpacity]}
                                min={20}
                                max={100}
                                step={5}
                                onValueChange={(value) => updateSetting("primaryColorOpacity", value[0])}
                                className="py-1"
                              />
                            </div>
                          </div>

                          {/* Secondary Color */}
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <Label className="text-xs">Secondary Color</Label>
                              <div className="flex items-center gap-2">
                                <div
                                  className="h-4 w-4 rounded-full border"
                                  style={{ backgroundColor: settings.secondaryColor }}
                                />
                                <span className="text-xs text-muted-foreground">{settings.secondaryColorOpacity}%</span>
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-2 justify-center py-2 bg-muted/20 dark:bg-muted/10 rounded-md p-2 border border-primary/10 dark:border-primary/20">
                              {[
                                { color: "hsl(215 20.2% 65.1%)", name: "Default" },
                                { color: "hsl(210 40% 96.1%)", name: "Light Gray" },
                                { color: "hsl(214 32% 91%)", name: "Lighter Gray" },
                                { color: "hsl(215 16% 47%)", name: "Medium Gray" },
                                { color: "hsl(215 25% 27%)", name: "Dark Gray" },
                              ].map(({ color, name }) => (
                                <div key={color} className="flex flex-col items-center gap-1">
                                  <button
                                    className={`w-8 h-8 rounded-full border-2 ${settings.secondaryColor === color ? 'border-primary ring-2 ring-primary/50 scale-110' : 'border-gray-300 dark:border-gray-600'} transition-all duration-200 hover:scale-110 shadow-sm hover:shadow-md`}
                                    style={{ backgroundColor: color }}
                                    onClick={() => updateSetting("secondaryColor", color)}
                                    title={name}
                                  />
                                  <span className="text-xs text-muted-foreground">{name}</span>
                                </div>
                              ))}
                            </div>
                            <div className="mt-4 space-y-2">
                              <div className="flex gap-2">
                                <div className="relative">
                                  <Input
                                    type="color"
                                    className="w-10 h-10 p-0 cursor-pointer opacity-0 absolute inset-0 z-10"
                                    value={settings.secondaryColor.startsWith('hsl') ? '#94a3b8' : settings.secondaryColor}
                                    onChange={(e) => {
                                      // Convert hex to HSL
                                      const hex = e.target.value;
                                      const r = parseInt(hex.slice(1, 3), 16) / 255;
                                      const g = parseInt(hex.slice(3, 5), 16) / 255;
                                      const b = parseInt(hex.slice(5, 7), 16) / 255;

                                      const max = Math.max(r, g, b);
                                      const min = Math.min(r, g, b);
                                      let h: number = 0;
                                      let s: number = 0;
                                      let l = (max + min) / 2;

                                      if (max === min) {
                                        h = s = 0; // achromatic
                                      } else {
                                        const d = max - min;
                                        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
                                        switch (max) {
                                          case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                                          case g: h = (b - r) / d + 2; break;
                                          case b: h = (r - g) / d + 4; break;
                                        }
                                        h /= 6;
                                      }

                                      h = Math.round(h * 360);
                                      s = Math.round(s * 100);
                                      l = Math.round(l * 100);

                                      updateSetting("secondaryColor", `hsl(${h} ${s}% ${l}%)`);
                                    }}
                                  />
                                  <div
                                    className="w-10 h-10 rounded-md border shadow-sm flex items-center justify-center relative overflow-hidden"
                                    style={{ backgroundColor: settings.secondaryColor }}
                                  >
                                    <Palette className="h-4 w-4 text-white mix-blend-difference" />
                                  </div>
                                </div>
                                <Input
                                  type="text"
                                  className="flex-1 h-10 text-xs"
                                  value={settings.secondaryColor}
                                  onChange={(e) => updateSetting("secondaryColor", e.target.value)}
                                  placeholder="hsl(215 20.2% 65.1%)"
                                />
                              </div>
                            </div>
                            <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                              <Slider
                                value={[settings.secondaryColorOpacity]}
                                min={20}
                                max={100}
                                step={5}
                                onValueChange={(value) => updateSetting("secondaryColorOpacity", value[0])}
                                className="py-1"
                              />
                            </div>
                          </div>

                          {/* Accent Color */}
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <Label className="text-xs">Accent Color</Label>
                              <div className="flex items-center gap-2">
                                <div
                                  className="h-4 w-4 rounded-full border"
                                  style={{ backgroundColor: settings.accentColor }}
                                />
                                <span className="text-xs text-muted-foreground">{settings.accentColorOpacity}%</span>
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-2 justify-center py-2 bg-muted/20 dark:bg-muted/10 rounded-md p-2 border border-primary/10 dark:border-primary/20">
                              {[
                                { color: "hsl(262.1 83.3% 57.8%)", name: "Purple" },
                                { color: "hsl(221.2 83.2% 53.3%)", name: "Blue" },
                                { color: "hsl(346.8 77.2% 49.8%)", name: "Red" },
                                { color: "hsl(142.1 76.2% 36.3%)", name: "Green" },
                                { color: "hsl(24.6 95% 53.1%)", name: "Orange" },
                              ].map(({ color, name }) => (
                                <div key={color} className="flex flex-col items-center gap-1">
                                  <button
                                    className={`w-8 h-8 rounded-full border-2 ${settings.accentColor === color ? 'border-primary ring-2 ring-primary/50 scale-110' : 'border-gray-300 dark:border-gray-600'} transition-all duration-200 hover:scale-110 shadow-sm hover:shadow-md`}
                                    style={{ backgroundColor: color }}
                                    onClick={() => updateSetting("accentColor", color)}
                                    title={name}
                                  />
                                  <span className="text-xs text-muted-foreground">{name}</span>
                                </div>
                              ))}
                            </div>
                            <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                              <Slider
                                value={[settings.accentColorOpacity]}
                                min={20}
                                max={100}
                                step={5}
                                onValueChange={(value) => updateSetting("accentColorOpacity", value[0])}
                                className="py-1"
                              />
                            </div>
                          </div>

                          {/* Background Color */}
                          <div className="space-y-2">
                            <div className="flex justify-between items-center">
                              <Label className="text-xs">Background Color</Label>
                              <div className="flex items-center gap-2">
                                <div
                                  className="h-4 w-4 rounded-full border"
                                  style={{ backgroundColor: settings.backgroundColor }}
                                />
                                <span className="text-xs text-muted-foreground">{settings.backgroundColorOpacity}%</span>
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-2 justify-center py-2 bg-muted/20 dark:bg-muted/10 rounded-md p-2 border border-primary/10 dark:border-primary/20">
                              {[
                                { color: "hsl(220 14.3% 95.9%)", name: "Light" },
                                { color: "hsl(0 0% 100%)", name: "White" },
                                { color: "hsl(220 13% 91%)", name: "Light Gray" },
                                { color: "hsl(215 27.9% 16.9%)", name: "Dark" },
                                { color: "hsl(224 71.4% 4.1%)", name: "Black" },
                              ].map(({ color, name }) => (
                                <div key={color} className="flex flex-col items-center gap-1">
                                  <button
                                    className={`w-8 h-8 rounded-full border-2 ${settings.backgroundColor === color ? 'border-primary ring-2 ring-primary/50 scale-110' : 'border-gray-300 dark:border-gray-600'} transition-all duration-200 hover:scale-110 shadow-sm hover:shadow-md`}
                                    style={{ backgroundColor: color }}
                                    onClick={() => updateSetting("backgroundColor", color)}
                                    title={name}
                                  />
                                  <span className="text-xs text-muted-foreground">{name}</span>
                                </div>
                              ))}
                            </div>
                            <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                              <Slider
                                value={[settings.backgroundColorOpacity]}
                                min={20}
                                max={100}
                                step={5}
                                onValueChange={(value) => updateSetting("backgroundColorOpacity", value[0])}
                                className="py-1"
                              />
                            </div>
                          </div>
                        </div>
                        {/* Color Preview */}
                        <div className="mt-6 border rounded-md p-4 space-y-3 bg-background/50">
                          <h4 className="text-sm font-medium flex items-center gap-1">
                            <Palette className="h-4 w-4" />
                            Color Preview
                          </h4>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="flex flex-col space-y-2">
                              <div className="h-12 rounded-md bg-primary flex items-center justify-center text-primary-foreground text-xs font-medium shadow-sm">
                                <div className="flex items-center gap-1.5">
                                  <div className="w-3 h-3 rounded-full bg-primary-foreground opacity-80"></div>
                                  Primary
                                </div>
                              </div>
                              <div className="h-12 rounded-md bg-secondary flex items-center justify-center text-secondary-foreground text-xs font-medium shadow-sm">
                                <div className="flex items-center gap-1.5">
                                  <div className="w-3 h-3 rounded-full bg-secondary-foreground opacity-80"></div>
                                  Secondary
                                </div>
                              </div>
                              <div className="h-12 rounded-md bg-accent flex items-center justify-center text-accent-foreground text-xs font-medium shadow-sm">
                                <div className="flex items-center gap-1.5">
                                  <div className="w-3 h-3 rounded-full bg-accent-foreground opacity-80"></div>
                                  Accent
                                </div>
                              </div>
                            </div>
                            <div className="flex flex-col space-y-2">
                              <div className="h-12 rounded-md bg-background border flex items-center justify-center text-foreground text-xs font-medium shadow-sm">
                                <div className="flex items-center gap-1.5">
                                  <div className="w-3 h-3 rounded-full bg-foreground opacity-80"></div>
                                  Background
                                </div>
                              </div>
                              <div className="h-12 rounded-md bg-muted flex items-center justify-center text-muted-foreground text-xs font-medium shadow-sm">
                                <div className="flex items-center gap-1.5">
                                  <div className="w-3 h-3 rounded-full bg-muted-foreground opacity-80"></div>
                                  Muted
                                </div>
                              </div>
                              <div className="h-12 rounded-md bg-destructive flex items-center justify-center text-destructive-foreground text-xs font-medium shadow-sm">
                                <div className="flex items-center gap-1.5">
                                  <div className="w-3 h-3 rounded-full bg-destructive-foreground opacity-80"></div>
                                  Destructive
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <Label className="text-xs">Border Radius</Label>
                          <span className="text-xs text-muted-foreground">{settings.borderRadius}px</span>
                        </div>
                        <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                          <Slider
                            value={[settings.borderRadius]}
                            min={0}
                            max={20}
                            step={1}
                            onValueChange={(value) => updateSetting("borderRadius", value[0])}
                            className="py-1"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <Label className="text-xs">Animations</Label>
                          <Switch
                            checked={settings.enableAnimations}
                            onCheckedChange={(checked) => updateSetting("enableAnimations", checked)}
                          />
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <Label className="text-xs ml-4">Animation Speed</Label>
                            <span className="text-xs text-muted-foreground">{settings.animationSpeed}ms</span>
                          </div>
                          <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                            <Slider
                              value={[settings.animationSpeed]}
                              min={100}
                              max={1000}
                              step={50}
                              disabled={!settings.enableAnimations}
                              onValueChange={(value) => updateSetting("animationSpeed", value[0])}
                              className="py-1"
                            />
                          </div>
                        </div>
                      </div>
                </TabsContent>

                <TabsContent value="typography" className="space-y-4 mt-0">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label className="text-xs">Base Font Size</Label>
                      <span className="text-xs text-muted-foreground">{settings.fontSize}px</span>
                    </div>
                    <div className="bg-muted/40 p-2 rounded-md dark:bg-muted/20">
                      <Slider
                        value={[settings.fontSize]}
                        min={12}
                        max={20}
                        step={1}
                        onValueChange={(value) => updateSetting("fontSize", value[0])}
                        className="py-1"
                      />
                    </div>
                  </div>

                  <div className="p-3 border rounded-md">
                    <h4 className="text-sm font-medium mb-2">Preview</h4>
                    <p className="text-sm mb-2" style={{ fontSize: `${settings.fontSize}px` }}>
                      This is how your text will look.
                    </p>
                    <p className="text-xs text-muted-foreground" style={{ fontSize: `${settings.fontSize - 2}px` }}>
                      This is smaller text for descriptions.
                    </p>
                  </div>
                </TabsContent>

                <TabsContent value="themes" className="space-y-4 mt-0">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label className="text-xs">Theme Name</Label>
                      <div className="flex gap-2">
                        <Input
                          value={themeName}
                          onChange={(e) => setThemeName(e.target.value)}
                          className="flex-1"
                          placeholder="My Custom Theme"
                        />
                        <Button
                          size="sm"
                          onClick={saveTheme}
                          className="whitespace-nowrap"
                        >
                          Save Theme
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="text-xs">Saved Themes</Label>
                      <div className="border rounded-md divide-y max-h-[200px] overflow-y-auto">
                        {savedThemes.length === 0 ? (
                          <div className="p-4 text-center text-sm text-muted-foreground">
                            No saved themes yet
                          </div>
                        ) : (
                          savedThemes.map((saved, index) => (
                            <div key={index} className="p-2 flex justify-between items-center hover:bg-muted/50">
                              <span className="text-sm">{saved.name}</span>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 w-7 p-0"
                                  onClick={() => loadTheme(saved.settings)}
                                >
                                  <Check className="h-3.5 w-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-7 w-7 p-0 text-destructive"
                                  onClick={() => {
                                    const newThemes = savedThemes.filter((_, i) => i !== index);
                                    setSavedThemes(newThemes);
                                    localStorage.setItem('ui-saved-themes', JSON.stringify(newThemes));
                                  }}
                                >
                                  <X className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </div>
            </Tabs>

            <div className="border-t p-3 flex justify-between">
              <Button
                variant="outline"
                size="sm"
                onClick={resetSettings}
                className="text-xs"
              >
                <RefreshCw className="h-3.5 w-3.5 mr-1" />
                Reset
              </Button>
              <Button
                size="sm"
                onClick={() => {
                  saveTheme();
                  setIsOpen(false);
                }}
                className="text-xs"
              >
                <Check className="h-3.5 w-3.5 mr-1" />
                Apply
              </Button>
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  );
};

export default ThemeCustomizer;
