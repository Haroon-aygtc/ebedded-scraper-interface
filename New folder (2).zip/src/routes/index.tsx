import React from "react";
import { Route, Routes, Navigate } from "react-router-dom";
import Home from "../components/home";
import AdminDashboard from "../pages/admin/dashboard";
import UserDashboard from "../pages/dashboard";
import LoginPage from "../pages/auth/login";
import ProtectedRoute from "../components/auth/ProtectedRoute";
import AdminRoute from "../components/auth/AdminRoute";

// Scraping Pages
import ScrapingIndexPage from "../pages/admin/scraping/index";
import ScrapingConfiguratorPage from "../pages/admin/scraping/configurator";
import SavedSelectorsPage from "../pages/admin/scraping/selectors";
import ScrapingHistoryPage from "../pages/admin/scraping/history";
import ScrapingProblemsPage from "../pages/admin/scraping/problems";
import ScrapingVisualizationPage from "../pages/admin/scraping/visualization";
import AdvancedSelectorPage from "../pages/admin/scraping/advanced-selector";

// Widget Config Page
import WidgetConfigPage from "../pages/admin/widget-config";

// Context Rules Pages
import ContextRulesIndexPage from "../pages/admin/context-rules/index";
import CreateContextRulePage from "../pages/admin/context-rules/create";
import ManageContextRulesPage from "../pages/admin/context-rules/manage";
import TestContextRulesPage from "../pages/admin/context-rules/test";

// Templates Pages
import TemplatesIndexPage from "../pages/admin/templates/index";
import CreateTemplatePage from "../pages/admin/templates/create";
import ManageTemplatesPage from "../pages/admin/templates/manage";

// Other Admin Pages
import EmbedCodePage from "../pages/admin/embed-code";
import AnalyticsPage from "../pages/admin/analytics";
import ResponseFormatterPage from "../pages/admin/response-formatter";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<LoginPage />} />

      {/* User Dashboard */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <UserDashboard />
          </ProtectedRoute>
        }
      />

      {/* Admin Dashboard */}
      <Route
        path="/admin/dashboard"
        element={
          <AdminRoute>
            <AdminDashboard />
          </AdminRoute>
        }
      />

      {/* Widget Config Route */}
      <Route
        path="/admin/widget-config"
        element={
          <AdminRoute>
            <WidgetConfigPage />
          </AdminRoute>
        }
      />

      {/* Context Rules Routes */}
      <Route
        path="/admin/context-rules"
        element={
          <AdminRoute>
            <ContextRulesIndexPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/context-rules/create"
        element={
          <AdminRoute>
            <CreateContextRulePage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/context-rules/manage"
        element={
          <AdminRoute>
            <ManageContextRulesPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/context-rules/test"
        element={
          <AdminRoute>
            <TestContextRulesPage />
          </AdminRoute>
        }
      />

      {/* Templates Routes */}
      <Route
        path="/admin/templates"
        element={
          <AdminRoute>
            <TemplatesIndexPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/templates/create"
        element={
          <AdminRoute>
            <CreateTemplatePage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/templates/manage"
        element={
          <AdminRoute>
            <ManageTemplatesPage />
          </AdminRoute>
        }
      />

      {/* Scraping Routes */}
      <Route
        path="/admin/scraping"
        element={
          <AdminRoute>
            <ScrapingIndexPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/scraping/configurator"
        element={
          <AdminRoute>
            <ScrapingConfiguratorPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/scraping/selectors"
        element={
          <AdminRoute>
            <SavedSelectorsPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/scraping/history"
        element={
          <AdminRoute>
            <ScrapingHistoryPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/scraping/problems"
        element={
          <AdminRoute>
            <ScrapingProblemsPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/scraping/visualization"
        element={
          <AdminRoute>
            <ScrapingVisualizationPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/scraping/advanced-selector"
        element={
          <AdminRoute>
            <AdvancedSelectorPage />
          </AdminRoute>
        }
      />

      {/* Other Admin Routes */}
      <Route
        path="/admin/embed-code"
        element={
          <AdminRoute>
            <EmbedCodePage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/analytics"
        element={
          <AdminRoute>
            <AnalyticsPage />
          </AdminRoute>
        }
      />
      <Route
        path="/admin/response-formatter"
        element={
          <AdminRoute>
            <ResponseFormatterPage />
          </AdminRoute>
        }
      />

      {/* Catch-all admin route */}
      <Route
        path="/admin/*"
        element={
          <AdminRoute>
            <Navigate to="/admin/dashboard" replace />
          </AdminRoute>
        }
      />
      {/* Add more routes as needed */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default AppRoutes;
