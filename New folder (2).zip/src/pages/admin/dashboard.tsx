import React, { useState } from "react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  Settings,
  MessageSquare,
  Code,
  BarChart3,
  FileText,
  MessageCircle,
  Globe,
} from "lucide-react";

import AdminLayout from "@/components/admin/AdminLayout";
import WidgetConfigurator from "@/components/admin/WidgetConfigurator";
import ContextRulesEditor from "@/components/admin/ContextRulesEditor";
import PromptTemplates from "@/components/admin/PromptTemplates";
import AnalyticsDashboard from "@/components/admin/AnalyticsDashboard";
import EmbedCodeGenerator from "@/components/admin/EmbedCodeGenerator";
import AIResponseFormatter from "@/components/admin/AIResponseFormatter";
import ScrapingConfigurator from "@/components/admin/scraping/ScrapingConfigurator";

const Dashboard = () => {
  const [activeSection, setActiveSection] = useState("overview");

  return (
    <AdminLayout>
      <div className="w-full py-6">
          <Tabs
            value={activeSection}
            onValueChange={setActiveSection}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-8 mb-8">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <LayoutDashboard className="h-4 w-4" />
                <span className="hidden sm:inline">Overview</span>
              </TabsTrigger>
              <TabsTrigger value="widget" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                <span className="hidden sm:inline">Widget Config</span>
              </TabsTrigger>
              <TabsTrigger value="context" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                <span className="hidden sm:inline">Context Rules</span>
              </TabsTrigger>
              <TabsTrigger
                value="templates"
                className="flex items-center gap-2"
              >
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">Templates</span>
              </TabsTrigger>
              <TabsTrigger value="embed" className="flex items-center gap-2">
                <Code className="h-4 w-4" />
                <span className="hidden sm:inline">Embed Code</span>
              </TabsTrigger>
              <TabsTrigger
                value="analytics"
                className="flex items-center gap-2"
              >
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">Analytics</span>
              </TabsTrigger>
              <TabsTrigger
                value="response-formatter"
                className="flex items-center gap-2"
              >
                <MessageCircle className="h-4 w-4" />
                <span className="hidden sm:inline">Response Formatter</span>
              </TabsTrigger>
              <TabsTrigger value="scraping" className="flex items-center gap-2">
                <Globe className="h-4 w-4" />
                <span className="hidden sm:inline">Web Scraping</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6 animate-fadeIn">
              <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 transition-all duration-300">
                <Card className="transform transition-all duration-300 hover:shadow-md hover:scale-[1.02] hover:border-primary/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">
                      Total Conversations
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">1,248</div>
                    <p className="text-xs text-muted-foreground">
                      +12% from last month
                    </p>
                  </CardContent>
                </Card>
                <Card className="transform transition-all duration-300 hover:shadow-md hover:scale-[1.02] hover:border-primary/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">
                      Active Users
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">342</div>
                    <p className="text-xs text-muted-foreground">
                      +5% from last month
                    </p>
                  </CardContent>
                </Card>
                <Card className="transform transition-all duration-300 hover:shadow-md hover:scale-[1.02] hover:border-primary/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">
                      Response Rate
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">98.7%</div>
                    <p className="text-xs text-muted-foreground">
                      +0.5% from last month
                    </p>
                  </CardContent>
                </Card>
                <Card className="transform transition-all duration-300 hover:shadow-md hover:scale-[1.02] hover:border-primary/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">
                      Avg. Response Time
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">1.2s</div>
                    <p className="text-xs text-muted-foreground">
                      -0.3s from last month
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid gap-4 sm:gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3 transition-all duration-300">
                <Card className="col-span-1 md:col-span-2 transform transition-all duration-300 hover:shadow-md hover:scale-[1.01] hover:border-primary/20">
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                    <CardDescription>
                      Common tasks and shortcuts
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    <Button
                      variant="outline"
                      className="h-24 flex flex-col items-center justify-center gap-2"
                      onClick={() => setActiveSection("widget")}
                    >
                      <Settings className="h-6 w-6" />
                      Configure Widget
                    </Button>
                    <Button
                      variant="outline"
                      className="h-24 flex flex-col items-center justify-center gap-2"
                      onClick={() => setActiveSection("context")}
                    >
                      <MessageSquare className="h-6 w-6" />
                      Edit Context Rules
                    </Button>
                    <Button
                      variant="outline"
                      className="h-24 flex flex-col items-center justify-center gap-2"
                      onClick={() => setActiveSection("embed")}
                    >
                      <Code className="h-6 w-6" />
                      Get Embed Code
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>System Status</CardTitle>
                    <CardDescription>Current system health</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">API Status</span>
                      <span className="text-sm font-medium text-green-600">
                        Operational
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Gemini API</span>
                      <span className="text-sm font-medium text-green-600">
                        Connected
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Hugging Face API</span>
                      <span className="text-sm font-medium text-green-600">
                        Connected
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Database</span>
                      <span className="text-sm font-medium text-green-600">
                        Healthy
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="widget" className="animate-fadeIn">
              <WidgetConfigurator />
            </TabsContent>

            <TabsContent value="context" className="animate-fadeIn">
              <ContextRulesEditor />
            </TabsContent>

            <TabsContent value="templates" className="animate-fadeIn">
              <PromptTemplates />
            </TabsContent>

            <TabsContent value="embed" className="animate-fadeIn">
              <EmbedCodeGenerator />
            </TabsContent>

            <TabsContent value="analytics" className="animate-fadeIn">
              <AnalyticsDashboard />
            </TabsContent>

            <TabsContent value="response-formatter" className="animate-fadeIn">
              <AIResponseFormatter />
            </TabsContent>

            <TabsContent value="scraping" className="animate-fadeIn">
              <ScrapingConfigurator />
            </TabsContent>
          </Tabs>
      </div>
    </AdminLayout>
  );
};

export default Dashboard;
