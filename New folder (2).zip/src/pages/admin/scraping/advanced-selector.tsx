import React from "react";
import AdvancedLiveSelectorTool from "@/components/admin/scraping/AdvancedLiveSelectorTool";
import SelectorInfoPanel from "@/components/admin/scraping/SelectorInfoPanel";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const AdvancedSelectorPage = () => {
  return (
    <AdminLayout>
      <div className="w-full py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Advanced Selector Tool</CardTitle>
                <CardDescription>
                  Create and test powerful selectors for web scraping with visual assistance
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdvancedLiveSelectorTool
                  onSaveSelectors={(selectors) => {
                    console.log("Selectors saved:", selectors);
                    // In a real implementation, you would save these to your backend
                  }}
                />
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <SelectorInfoPanel className="sticky top-6" />

            <Card className="mt-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20 dark:border-primary/30">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Recent Selectors</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: "Product Title", selector: ".product-title", date: "2 hours ago" },
                  { name: "Price", selector: ".price-tag", date: "Yesterday" },
                  { name: "Description", selector: ".product-description", date: "3 days ago" },
                ].map((item, index) => (
                  <div key={index} className="p-2 bg-white dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-700 hover:border-primary/30 transition-colors cursor-pointer">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-sm">{item.name}</p>
                        <code className="text-xs bg-gray-100 dark:bg-gray-900 px-1 py-0.5 rounded">{item.selector}</code>
                      </div>
                      <span className="text-xs text-gray-500">{item.date}</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdvancedSelectorPage;
