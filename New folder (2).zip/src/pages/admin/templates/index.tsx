import React from "react";
import { Navigate } from "react-router-dom";

const TemplatesIndexPage = () => {
  return <Navigate to="/admin/templates/manage" replace />;
};

export default TemplatesIndexPage;
