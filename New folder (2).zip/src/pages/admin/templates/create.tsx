import React from "react";
import PromptTemplates from "@/components/admin/PromptTemplates";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const CreateTemplatePage = () => {
  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Create Prompt Template</CardTitle>
            <CardDescription>
              Create new prompt templates for your chat widget
            </CardDescription>
          </CardHeader>
          <CardContent>
            <PromptTemplates />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default CreateTemplatePage;
