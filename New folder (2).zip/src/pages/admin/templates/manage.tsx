import React from "react";
import PromptTemplates from "@/components/admin/PromptTemplates";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const ManageTemplatesPage = () => {
  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Manage Prompt Templates</CardTitle>
            <CardDescription>
              View and edit your existing prompt templates
            </CardDescription>
          </CardHeader>
          <CardContent>
            <PromptTemplates />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default ManageTemplatesPage;
