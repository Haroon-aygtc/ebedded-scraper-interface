import React from "react";
import WidgetConfigurator from "@/components/admin/WidgetConfigurator";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const WidgetConfigPage = () => {
  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Widget Configuration</CardTitle>
            <CardDescription>
              Customize the appearance and behavior of your chat widget
            </CardDescription>
          </CardHeader>
          <CardContent>
            <WidgetConfigurator />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default WidgetConfigPage;
