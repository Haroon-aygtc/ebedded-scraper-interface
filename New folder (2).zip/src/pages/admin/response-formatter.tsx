import React from "react";
import AIResponseFormatter from "@/components/admin/AIResponseFormatter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const ResponseFormatterPage = () => {
  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>AI Response Formatter</CardTitle>
            <CardDescription>
              Customize how AI responses are formatted and add follow-up questions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <AIResponseFormatter />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default ResponseFormatterPage;
