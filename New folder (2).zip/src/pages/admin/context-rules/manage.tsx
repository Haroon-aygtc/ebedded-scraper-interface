import React from "react";
import ContextRulesEditor from "@/components/admin/ContextRulesEditor";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const ManageContextRulesPage = () => {
  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Manage Context Rules</CardTitle>
            <CardDescription>
              View and edit your existing context rules
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ContextRulesEditor />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default ManageContextRulesPage;
