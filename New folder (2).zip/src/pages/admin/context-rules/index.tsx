import React from "react";
import { Navigate } from "react-router-dom";

const ContextRulesIndexPage = () => {
  return <Navigate to="/admin/context-rules/manage" replace />;
};

export default ContextRulesIndexPage;
