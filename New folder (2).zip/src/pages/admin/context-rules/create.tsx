import React from "react";
import ContextRulesEditor from "@/components/admin/ContextRulesEditor";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const CreateContextRulePage = () => {
  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Create Context Rule</CardTitle>
            <CardDescription>
              Define new context rules for your chat widget
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ContextRulesEditor />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default CreateContextRulePage;
