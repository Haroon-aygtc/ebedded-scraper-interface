import React from "react";
import ContextRulesEditor from "@/components/admin/ContextRulesEditor";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const TestContextRulesPage = () => {
  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Test Context Rules</CardTitle>
            <CardDescription>
              Test your context rules with sample queries
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ContextRulesEditor />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default TestContextRulesPage;
