import React from "react";
import EmbedCodeGenerator from "@/components/admin/EmbedCodeGenerator";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import AdminLayout from "@/components/admin/AdminLayout";

const EmbedCodePage = () => {
  return (
    <AdminLayout>
      <div className="container mx-auto py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Embed Code Generator</CardTitle>
            <CardDescription>
              Generate code to embed the chat widget on your website
            </CardDescription>
          </CardHeader>
          <CardContent>
            <EmbedCodeGenerator />
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
};

export default EmbedCodePage;
