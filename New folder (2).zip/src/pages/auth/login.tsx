import LoginForm from "@/components/auth/LoginForm";

const LoginPage = () => {
  return <LoginForm />;
};

export default LoginPage;
