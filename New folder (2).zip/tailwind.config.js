/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsla(var(--border), var(--border-opacity, 1))",
        input: "hsla(var(--input), var(--input-opacity, 1))",
        ring: "hsla(var(--ring), var(--ring-opacity, 1))",
        background: "hsla(var(--background), var(--background-opacity, 1))",
        foreground: "hsla(var(--foreground), var(--foreground-opacity, 1))",
        primary: {
          DEFAULT: "hsla(var(--primary), var(--primary-opacity, 1))",
          foreground: "hsla(var(--primary-foreground), var(--primary-foreground-opacity, 1))",
        },
        secondary: {
          DEFAULT: "hsla(var(--secondary), var(--secondary-opacity, 1))",
          foreground: "hsla(var(--secondary-foreground), var(--secondary-foreground-opacity, 1))",
        },
        destructive: {
          DEFAULT: "hsla(var(--destructive), var(--destructive-opacity, 1))",
          foreground: "hsla(var(--destructive-foreground), var(--destructive-foreground-opacity, 1))",
        },
        muted: {
          DEFAULT: "hsla(var(--muted), var(--muted-opacity, 1))",
          foreground: "hsla(var(--muted-foreground), var(--muted-foreground-opacity, 1))",
        },
        accent: {
          DEFAULT: "hsla(var(--accent), var(--accent-opacity, 1))",
          foreground: "hsla(var(--accent-foreground), var(--accent-foreground-opacity, 1))",
        },
        popover: {
          DEFAULT: "hsla(var(--popover), var(--popover-opacity, 1))",
          foreground: "hsla(var(--popover-foreground), var(--popover-foreground-opacity, 1))",
        },
        card: {
          DEFAULT: "hsla(var(--card), var(--card-opacity, 1))",
          foreground: "hsla(var(--card-foreground), var(--card-foreground-opacity, 1))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "fadeIn": {
          from: { opacity: "0", transform: "translateY(-10px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        "fadeOut": {
          from: { opacity: "1", transform: "translateY(0)" },
          to: { opacity: "0", transform: "translateY(-10px)" },
        },
        "pulse": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.5" },
        },
        "bounce": {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-5px)" },
        },
        "spin-slow": {
          from: { transform: "rotate(0deg)" },
          to: { transform: "rotate(360deg)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fadeIn": "fadeIn 0.3s ease-out",
        "fadeOut": "fadeOut 0.3s ease-out",
        "pulse": "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "bounce": "bounce 1s ease-in-out infinite",
        "spin-slow": "spin-slow 3s linear infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
